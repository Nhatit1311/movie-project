<?php

namespace App\Http\Controllers;

use App\Models\XemPhim;
use Illuminate\Http\Request;

class XemPhimController extends Controller
{
    /**
     * Display a listing of the resource.
     */
}
