<?php $__env->startSection('title'); ?>
    Phim Hay
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="container__banner">
    <div class="swiper mySwiper">
        <div class="swiper-wrapper">
            <div class="swiper-slide">
                <img src="/assets/img/banner/poster-phim-hanh-dong.jpg" alt=""
                    srcset="/assets/img/banner/poster-phim-hanh-dong.jpg">
            </div>
            <div class="swiper-slide">
                <img src="/assets/img/banner/poster-phim-hanh-dong.jpg" alt=""
                    srcset="/assets/img/banner/poster-phim-hanh-dong.jpg">
            </div>
            <div class="swiper-slide">
                <img src="/assets/img/banner/poster-phim-hanh-dong.jpg" alt=""
                    srcset="/assets/img/banner/poster-phim-hanh-dong.jpg">
            </div>
            <div class="swiper-slide">
                <img src="/assets/img/banner/poster-phim-hanh-dong.jpg" alt=""
                    srcset="/assets/img/banner/poster-phim-hanh-dong.jpg">
            </div>
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-pagination"></div>
    </div>
</section>
<section class="container__movie">
    <div class="container__movie-item">
        <h2 class="container__movie-phim-noi-bat" style="font-weight: 600;">Phim Đề Cử</h2>
        <div class="swiper mySlideMovie">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $list_phim_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <a href="/chi-tiet-phim/<?php echo e($value->slug_ten_phim); ?>-<?php echo e($value->id); ?>" title="<?php echo e($value->ten_phim); ?>">
                        <div class="scale">
                            <img src="<?php echo e($value->hinh_anh); ?>" alt="<?php echo e($value->ten_phim); ?>"
                                srcset="<?php echo e($value->hinh_anh); ?>">
                        </div>
                        <div class="movie-title">
                            <p><?php echo e($value->ten_phim); ?></p>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
    <div class="container__movie-item">
        <h2 class="container__movie-phim-noi-bat" style="font-weight: 600;">Phim Nổi Bật</h2>
        <div class="swiper mySlideMovie">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $list_phim_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <a href="/chi-tiet-phim/<?php echo e($value->slug_ten_phim); ?>-<?php echo e($value->id); ?>" title="<?php echo e($value->ten_phim); ?>">
                        <div class="scale">
                            <img src="<?php echo e($value->hinh_anh); ?>" alt="<?php echo e($value->ten_phim); ?>"
                                srcset="<?php echo e($value->hinh_anh); ?>">
                        </div>
                        <div class="movie-title">
                            <p><?php echo e($value->ten_phim); ?></p>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
    <div class="container__movie-item">
        <h2 id="phimlemoinhat" class="container__movie-phim-noi-bat" style="font-weight: 600;">Phim Lẻ Mới Cập Nhật</h2>
        <div class="swiper mySlideMovie">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $list_phim_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <a href="/chi-tiet-phim/<?php echo e($value->slug_ten_phim); ?>-<?php echo e($value->id); ?>" title="<?php echo e($value->ten_phim); ?>">
                        <div class="scale">
                            <img src="<?php echo e($value->hinh_anh); ?>" alt="<?php echo e($value->ten_phim); ?>"
                                srcset="<?php echo e($value->hinh_anh); ?>">
                        </div>
                        <div class="movie-title">
                            <p><?php echo e($value->ten_phim); ?></p>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
    <div class="container__movie-item">
        <h2 class="container__movie-phim-noi-bat" style="font-weight: 600;">Phim Hoạt Hình</h2>
        <div class="swiper mySlideMovie">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $list_phim_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <a href="/chi-tiet-phim/<?php echo e($value->slug_ten_phim); ?>-<?php echo e($value->id); ?>" title="<?php echo e($value->ten_phim); ?>">
                        <div class="scale">
                            <img src="<?php echo e($value->hinh_anh); ?>" alt="<?php echo e($value->ten_phim); ?>"
                                srcset="<?php echo e($value->hinh_anh); ?>">
                        </div>
                        <div class="movie-title">
                            <p><?php echo e($value->ten_phim); ?></p>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('clients.share.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-movie\resources\views/clients/page/homepage.blade.php ENDPATH**/ ?>