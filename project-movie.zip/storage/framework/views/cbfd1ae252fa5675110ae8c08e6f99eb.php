<?php $__env->startSection('title'); ?>
    Phim <?php echo e(isset($detail_phim) ? $detail_phim->ten_phim : ''); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="container">
    <div class="container__title">
        <span style="color: #7aa6ce;">Phim Hay</span> <span style="color: gray;">>></span>
        <span style="color: #7aa6ce;"><?php echo e(isset($detail_phim) ? $detail_phim->quoc_gia : ''); ?></span> <span style="color: gray;">>></span>
        <span style="color: gray;"><?php echo e(isset($detail_phim) ? $detail_phim->ten_phim : ''); ?></span>
    </div>
    <div class="container__detail-movie">
        <div class="container__detail-img">
            <a href="<?php echo e(route('phim',['slug'=>$detail_phim->slug_ten_phim])); ?>">
                <img src="<?php echo e(isset($detail_phim) ? $detail_phim->hinh_anh : ''); ?>" alt="<?php echo e(isset($detail_phim) ? $detail_phim->ten_phim : ''); ?>">
            </a>
            <div class="container__detail-button" align="center">
                <a href="<?php echo e(route('trailer',['slug'=>$detail_phim->slug_ten_phim])); ?>">
                    <button class="trailer"><span>Trailer</span></button>
                </a>
                <a href="<?php echo e(route('phim',['slug'=>$detail_phim->slug_ten_phim])); ?>">
                    <button class="xem-phim">
                        <span>
                            Xem Phim
                        </span>
                    </button>
                </a>
            </div>
        </div>
        <div class="container__detail-title">
            <h3 style="color: #ffed4d; font-weight: 500"><?php echo e(isset($detail_phim) ? $detail_phim->ten_phim : ''); ?></h3>
            <h5 style="color: gray; font-weight: 500">Black Widow (2021)</h5>
            <ul class="list-detail">
                <li>
                    <span>Trạng Thái</span>
                    :
                    <span class="quanlity">HD</span>
                    <span class="episode">Vietsub</span>
                </li>
                <li>
                    <span>Thời Lượng</span>
                    : <?php echo e(isset($detail_phim) ? $detail_phim->thoi_luong : ''); ?> Phút
                </li>
                <li>
                    <span>Thể Loại</span>:
                    <a href="" rel="category tag"><?php echo e(isset($detail_phim) ? $detail_phim->the_loai : ''); ?></a>,
                </li>
                <li>
                    <span>Quốc Gia</span>:
                    <a href=""><?php echo e(isset($detail_phim) ? $detail_phim->quoc_gia : ''); ?></a>
                </li>
                <li>
                    <span>Đạo Diễn</span>:
                    <a href=""><?php echo e(isset($detail_phim) ? $detail_phim->dao_dien : ''); ?></a>
                </li>
                <li>
                    <span>Diễn Viên</span>:
                    <a href="" rel="nofollow" title="C.C. Smiff"><?php echo e(isset($detail_phim) ? $detail_phim->dien_vien : ''); ?></a>
                </li>
            </ul>
        </div>
    </div>
    <div class="container__detail-content">
        <h2>Nội Dung Phim</h2>
        <div class="content__detail-mo-ta">
            <p>Phim <?php echo e(isset($detail_phim) ? $detail_phim->ten_phim : ''); ?> - 2021 - <?php echo e(isset($detail_phim) ? $detail_phim->quoc_gia : ''); ?>:</p>
            <p style="text-align: justify;"><?php echo e(isset($detail_phim) ? $detail_phim->mo_ta : ''); ?></p>
        </div>
    </div>
</section>
<section class="container__movie">
    <div class="container__movie-item">
        <h2 class="container__movie-phim-noi-bat" style="font-weight: 600;">Có Thể Bạn Muốn Xem</h2>
        <div class="swiper mySlideMovie">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $list_phim_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <a href="/chi-tiet-phim/<?php echo e($value->slug_ten_phim); ?>-<?php echo e($value->id); ?>" title="<?php echo e($value->slug_ten_phim); ?>">
                        <div class="scale">
                            <img src="<?php echo e($value->hinh_anh); ?>" alt="<?php echo e($value->slug_ten_phim); ?>"
                            srcset="<?php echo e($value->hinh_anh); ?>">
                        </div>
                        <div class="movie-title">
                            <p><?php echo e($value->ten_phim); ?></p>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('clients.share.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-movie\resources\views/clients/page/chi_tiet_phim.blade.php ENDPATH**/ ?>