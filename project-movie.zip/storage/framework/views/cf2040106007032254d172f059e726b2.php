<?php $__env->startSection('title'); ?>
    Xem Phim <?php echo e($xem_phim->ten_phim); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="container">
    <div class="container__title">
        <span style="color: #7aa6ce;">Phim Hay</span> <span style="color: gray;">>></span>
        <span style="color: #7aa6ce;"><?php echo e($xem_phim->quoc_gia); ?></span> <span style="color: gray;">>></span>
        <span style="color: gray;"><?php echo e($xem_phim->ten_phim); ?></span>
    </div>
    <div class="container__watch">
        <iframe width="100%" height="700" src="<?php echo e($xem_phim->link_phim); ?>"
            title="YouTube video player" frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen>
        </iframe>
    </div>
    <div class="container__watch-title">
        <h2 style="font-weight: 600; ">
            <a style="color: #a5a5a5;" href="/phim"><?php echo e($xem_phim->ten_phim); ?></a>
        </h2>
    </div>
    <div class="container__row">
        <div class="container__watch-tap-phim">
            <div class="viet-sub">
                <span>VietSub</span>
            </div>
        </div>
    </div>
    <div class="container__watch_list-tap-phim">
        <div class="container__watch-item">
            <span>1</span>
        </div>
        <div class="container__watch-item">
            <span>2</span>
        </div>
        <div class="container__watch-item">
            <span>3</span>
        </div>
        <div class="container__watch-item">
            <span>4</span>
        </div>
        <div class="container__watch-item">
            <span>5</span>
        </div>
        <div class="container__watch-item">
            <span>6</span>
        </div>
        <div class="container__watch-item">
            <span>7</span>
        </div>
        <div class="container__watch-item">
            <span>8</span>
        </div>
        <div class="container__watch-item">
            <span>9</span>
        </div>
        <div class="container__watch-item">
            <span>10</span>
        </div>
    </div>
</section>
<section class="container__movie">
    <div class="container__movie-item">
        <h2 class="container__movie-phim-noi-bat" style="font-weight: 600;">Có Thể Bạn Muốn Xem</h2>
        <div class="swiper mySlideMovie">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $list_phim_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <a href="/chi-tiet-phim/<?php echo e($value->slug_ten_phim); ?>-<?php echo e($value->id); ?>">
                        <div class="scale">
                            <img src="<?php echo e($value->hinh_anh); ?>" alt="<?php echo e($value->ten_phim); ?>">
                        </div>
                        <div class="movie-title">
                            <p><?php echo e($value->ten_phim); ?></p>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('clients.share.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-movie\resources\views/clients/page/xem_phim.blade.php ENDPATH**/ ?>