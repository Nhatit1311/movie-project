<?php $__env->startSection('content'); ?>
<section class="container__movie">
    <div class="container__movie-item">
        <h2 class="container__movie-phim-noi-bat" style="font-weight: 600; padding: 1.5rem 0">Phim Mới Nổi Bật</h2>
        <div class="swiper mySlideMovie">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $list_phim_moi_noi_bat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <a href="/chi-tiet-phim/<?php echo e($value->slug_ten_phim); ?>-<?php echo e($value->id); ?>" title="<?php echo e($value->ten_phim); ?>">
                        <div class="scale">
                            <img src="<?php echo e($value->hinh_anh); ?>" alt="<?php echo e($value->ten_phim); ?>"
                                srcset="<?php echo e($value->hinh_anh); ?>">
                        </div>
                        <div class="movie-title">
                            <p><?php echo e($value->ten_phim); ?></p>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section>
<section class="container">
    <h1 style="color: #fff; padding: 1.5rem 0; font-weight: 600; font-size: 3rem">Phim Mới</h1>
    <div class="container__phim__moi" align="center">
        <?php $__currentLoopData = $list_phim_moi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container__phim__moi-item">
            <a href="/chi-tiet-phim/<?php echo e($value->slug_ten_phim); ?>-<?php echo e($value->id); ?>" title="<?php echo e($value->ten_phim); ?>">
                <div class="container__phim__moi-img">
                    <img src="<?php echo e($value->hinh_anh); ?>" alt="<?php echo e($value->ten_phim); ?>">
                </div>
                <div class="container__phim_moi-title">
                    <p><?php echo e($value->ten_phim); ?></p>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('clients.share.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-movie\resources\views/clients/page/phim_moi.blade.php ENDPATH**/ ?>